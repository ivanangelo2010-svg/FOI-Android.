# FOI Android

Proyecto base de FOI para Android.

## APK automático con GitHub Actions

Cada vez que subas cambios a `main`, GitHub ejecutará:

**Actions → Build FOI APK**

Si el build termina en verde:

1. Abre la ejecución.
2. Baja hasta **Artifacts**.
3. Descarga **FOI-APK**.
4. Dentro estará `FOI-debug.apk`.

## Incluye

- Interfaz oscura FOI
- Chat local
- Memoria local sencilla
- Calculadora sencilla
- Voz TTS de Android
- Micrófono / reconocimiento de voz del dispositivo

Esta primera versión evita librerías externas para maximizar la posibilidad de compilación.
